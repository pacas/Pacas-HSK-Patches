﻿using System;
using System.Collections.Generic;
using HugsLib;

namespace ADA
{
	// Token: 0x02000010 RID: 16
	internal class ModBaseADA : ModBase
	{
		// Token: 0x0600004D RID: 77 RVA: 0x000049F0 File Offset: 0x00002BF0
		public override void DefsLoaded()
		{
			ModBaseADA.settings = new Settings(base.Settings);
		}

		// Token: 0x0600004E RID: 78 RVA: 0x00004A03 File Offset: 0x00002C03
		public static void RegisterTickAction(Action action)
		{
			ModBaseADA.TickActions.Add(action);
		}

		// Token: 0x0600004F RID: 79 RVA: 0x00004A14 File Offset: 0x00002C14
		public override void Tick(int currentTick)
		{
			foreach (Action action in ModBaseADA.TickActions)
			{
				action();
			}
			ModBaseADA.TickActions.Clear();
		}

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x06000050 RID: 80 RVA: 0x00004A78 File Offset: 0x00002C78
		public override string ModIdentifier
		{
			get
			{
				return "ADA";
			}
		}

		// Token: 0x04000023 RID: 35
		public static Settings settings;

		// Token: 0x04000024 RID: 36
		private static List<Action> TickActions = new List<Action>();
	}
}
