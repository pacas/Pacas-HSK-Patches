﻿using Verse;

namespace ADA
{
	// Token: 0x02000009 RID: 9
	public class CompProperties_HitTop : CompProperties
	{
		// Token: 0x06000045 RID: 69 RVA: 0x00004626 File Offset: 0x00002826
		public CompProperties_HitTop()
		{
			this.compClass = typeof(CompHitTop);
		}
	}
}
