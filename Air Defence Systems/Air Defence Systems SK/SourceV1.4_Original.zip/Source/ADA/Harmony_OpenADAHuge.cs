﻿using System.Linq;
using HarmonyLib;
using RimWorld;
using Verse;

namespace ADA
{
	// Token: 0x0200000D RID: 13
	[HarmonyPatch(typeof(TaleManager), "Add")]
	public static class Harmony_OpenADAHuge
	{
		// Token: 0x0600004A RID: 74 RVA: 0x000047C4 File Offset: 0x000029C4
		public static void Postfix(Tale tale)
		{
			bool flag = tale != null && tale.def.defName == "ShipPartCrash";
			if (flag)
			{
				foreach (Map map in Find.Maps)
				{
					bool isPlayerHome = map.IsPlayerHome;
					if (isPlayerHome)
					{
						bool flag2 = map.listerBuildings.AllBuildingsColonistOfClass<Building_AirDefense>().ToList<Building_AirDefense>().Count > 0;
						if (flag2)
						{
							Messages.Message("ADA Open!", MessageTypeDefOf.PositiveEvent, false);
						}
						foreach (Building_AirDefense building_AirDefense in map.listerBuildings.AllBuildingsColonistOfClass<Building_AirDefense>())
						{
							bool canShotShip = building_AirDefense.TopSizeComp.Props.canShotShip;
							if (canShotShip)
							{
								building_AirDefense.OpenTick = 400;
							}
						}
					}
				}
			}
		}
	}
}
