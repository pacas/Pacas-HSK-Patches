﻿using HarmonyLib;
using Verse;

namespace ADA
{
	// Token: 0x0200000F RID: 15
	//[HarmonyPatch(typeof(Projectile), "DeSpawn", null)]
	[HarmonyPatch(typeof(Projectile), "DeSpawn")]
	internal static class Harmony_Projectile_Die
	{
		// Token: 0x0600004C RID: 76 RVA: 0x0000495C File Offset: 0x00002B5C
		public static void Prefix(Projectile __instance)
		{
			bool flag = __instance.def.projectile != null && __instance.def.projectile.flyOverhead;
			if (flag)
			{
				foreach (ProjectileEnd projectileEnd in BulletStore.theBullet)
				{
					bool flag2 = projectileEnd.shell == __instance;
					if (flag2)
					{
						BulletStore.theBullet.Remove(projectileEnd);
						break;
					}
				}
			}
		}
	}
}
