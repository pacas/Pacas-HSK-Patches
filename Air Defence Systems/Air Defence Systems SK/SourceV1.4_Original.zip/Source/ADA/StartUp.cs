﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using RimWorld.Planet;
using UnityEngine;
using Verse;

namespace ADA
{
	// Token: 0x02000014 RID: 20
	[StaticConstructorOnStartup]
	public static class StartUp
	{
		// Token: 0x06000058 RID: 88 RVA: 0x00004B72 File Offset: 0x00002D72
		static StartUp()
		{
			//HarmonyInstance.Create("A-D-A").PatchAll(Assembly.GetExecutingAssembly());
			Harmony harmony = new Harmony("A-D-A");
			harmony.PatchAll();
		}
	}
}
