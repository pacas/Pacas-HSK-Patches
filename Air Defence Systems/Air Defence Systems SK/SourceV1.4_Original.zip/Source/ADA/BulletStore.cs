﻿using System.Collections.Generic;

namespace ADA
{
	// Token: 0x02000005 RID: 5
	public class BulletStore
	{
		// Token: 0x04000013 RID: 19
		public static List<ProjectileEnd> theBullet = new List<ProjectileEnd>();
	}
}
