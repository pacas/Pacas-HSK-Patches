﻿using System;
using Verse;

namespace ADA
{
	// Token: 0x0200000B RID: 11
	public class CompTurretTopSize : ThingComp
	{
		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06000047 RID: 71 RVA: 0x000046AB File Offset: 0x000028AB
		public CompProperties_TurretTopSize Props
		{
			get
			{
				return (CompProperties_TurretTopSize)this.props;
			}
		}
	}
}
