﻿using System.Text;
using RimWorld;
using UnityEngine;
using Verse;

namespace ADA
{
	// Token: 0x02000007 RID: 7
	public class CompHitTop : ThingComp
	{
		// Token: 0x0600003B RID: 59 RVA: 0x00004358 File Offset: 0x00002558
		public override string CompInspectStringExtra()
		{
			StringBuilder stringBuilder = new StringBuilder();
			bool flag = this.cooldownticks > 0;
			if (flag)
			{
				stringBuilder.Append(Translator.Translate("atkTicks") + ":" + ((float)this.cooldownticks * 1f / 60f).ToString("f1") + Translator.Translate("ra2Sec"));
			}
			return stringBuilder.ToString();
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x0600003C RID: 60 RVA: 0x000043C8 File Offset: 0x000025C8
		// (set) Token: 0x0600003D RID: 61 RVA: 0x000043E0 File Offset: 0x000025E0
		public float CurRotation
		{
			get
			{
				return this.curRotationInt;
			}
			set
			{
				this.curRotationInt = value;
				bool flag = (double)this.curRotationInt > 360.0;
				if (flag)
				{
					this.curRotationInt -= 360f;
				}
				bool flag2 = (double)this.curRotationInt < 0.0;
				if (flag2)
				{
					this.curRotationInt += 360f;
				}
			}
		}

		// Token: 0x0600003E RID: 62 RVA: 0x00004449 File Offset: 0x00002649
		public override void PostExposeData()
		{
			Scribe_Values.Look<int>(ref this.cooldownticks, "cooldownticks", 0, false);
		}

		// Token: 0x0600003F RID: 63 RVA: 0x00004460 File Offset: 0x00002660
		public override void CompTick()
		{
			base.CompTick();
			bool flag = this.cooldownticks > 0;
			if (flag)
			{
				this.cooldownticks--;
			}
			bool flag2 = ThingCompUtility.TryGetComp<CompHitPassingShip>(this.parent) != null && ThingCompUtility.TryGetComp<CompHitPassingShip>(this.parent).Fiya;
			if (flag2)
			{
				CompHitPassingShip compHitPassingShip = ThingCompUtility.TryGetComp<CompHitPassingShip>(this.parent);
				this.speed = 0.3f + 15f * compHitPassingShip.getPercent();
			}
			else
			{
				this.speed = 0.3f + 15f * this.getCDPercent();
			}
			bool flag3 = !ThingCompUtility.TryGetComp<CompPowerTrader>(this.parent).PowerOn;
			if (flag3)
			{
				this.speed = 0f;
			}
			this.rotate(this.speed);
		}

		// Token: 0x06000040 RID: 64 RVA: 0x00004527 File Offset: 0x00002727
		private void rotate(float speed)
		{
			this.CurRotation += speed;
		}

		// Token: 0x06000041 RID: 65 RVA: 0x0000453C File Offset: 0x0000273C
		public override void PostDraw()
		{
			Matrix4x4 matrix4x = default(Matrix4x4);
			matrix4x.SetTRS(this.parent.DrawPos + Altitudes.AltIncVect + new Vector3(0f, 1f, 0f), GenMath.ToQuat(this.CurRotation), new Vector3(7f, 7f, 7f));
			Graphics.DrawMesh(MeshPool.plane20, matrix4x, this.parent.def.building.turretTopMat, 0);
		}

		// Token: 0x06000042 RID: 66 RVA: 0x000045CC File Offset: 0x000027CC
		public float getCDPercent()
		{
			return (float)this.cooldownticks * 1f / 600f;
		}

		// Token: 0x04000017 RID: 23
		private float curRotationInt;

		// Token: 0x04000018 RID: 24
		private float speed = 2f;

		// Token: 0x04000019 RID: 25
		public int cooldownticks = 0;
	}
}
