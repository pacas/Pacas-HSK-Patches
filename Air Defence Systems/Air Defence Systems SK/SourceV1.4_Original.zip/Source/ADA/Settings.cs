﻿using HugsLib.Settings;
using Verse;

namespace ADA
{
	// Token: 0x02000013 RID: 19
	internal class Settings
	{
		// Token: 0x06000056 RID: 86 RVA: 0x00004B1B File Offset: 0x00002D1B
		public Settings(ModSettingsPack settings)
		{
			Settings.droppodCargoDropPercentage = settings.GetHandle<int>("adadroppodCargoDropPercentage", Translator.Translate("ADADroppodCargoDropPercentage"), Translator.Translate("ADADroppodCargoDropPercentageDesc"), 30, Settings.AtLeast(), null);
		}

		// Token: 0x06000057 RID: 87 RVA: 0x00004B51 File Offset: 0x00002D51
		private static SettingHandle.ValueIsValid AtLeast()
		{
			return delegate(string value)
			{
				int num;
				return int.TryParse(value, out num) && num <= 100 && num >= 0;
			};
		}

		// Token: 0x04000029 RID: 41
		public static SettingHandle<int> droppodCargoDropPercentage;
	}
}
