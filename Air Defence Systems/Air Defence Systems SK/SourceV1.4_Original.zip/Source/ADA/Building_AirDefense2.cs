﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace ADA
{
	// Token: 0x02000003 RID: 3
	public class Building_AirDefense2 : Building
	{
		// Token: 0x06000018 RID: 24 RVA: 0x00002F04 File Offset: 0x00001104
		public Building_AirDefense2()
		{
			this.top = new TurretTop_CustomSize(this);
			this.stunner = new StunHandler(this);
			this.nowTarget = null;
		}

		// Token: 0x06000019 RID: 25 RVA: 0x00002F5C File Offset: 0x0000115C
		public override string GetInspectString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append(base.GetInspectString());
			if (this.underRoof)
			{
				stringBuilder.Append("\n" + Translator.Translate("ADAUnderRoof"));
			}
			return stringBuilder.ToString();
		}

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x0600001A RID: 26 RVA: 0x00002FAA File Offset: 0x000011AA
		private IEnumerable<IntVec3> AirCells
		{
			get
			{
				return this.AirCellsAround(base.Position, base.Map);
			}
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x0600001B RID: 27 RVA: 0x00002FC0 File Offset: 0x000011C0
		private bool ShouldAttackNow
		{
			get
			{
				bool result;
				if (!base.Spawned)
				{
					result = false;
				}
				else if (!FlickUtility.WantsToBeOn(this))
				{
					result = false;
				}
				else if (this.underRoof)
				{
					result = false;
				}
				else
				{
					CompPowerTrader compPowerTrader = ThingCompUtility.TryGetComp<CompPowerTrader>(this);
					if (compPowerTrader != null && !compPowerTrader.PowerOn)
					{
						result = false;
					}
					else if (this.stunner.Stunned)
					{
						result = false;
					}
					else
					{
						CompRefuelable compRefuelable = ThingCompUtility.TryGetComp<CompRefuelable>(this);
						result = (compRefuelable == null || compRefuelable.HasFuel);
					}
				}
				return result;
			}
		}

		// Token: 0x0600001C RID: 28 RVA: 0x0000303C File Offset: 0x0000123C
		public override void Tick()
		{
			base.Tick();
			this.doTurretTick();
			CompPowerTrader compPowerTrader = ThingCompUtility.TryGetComp<CompPowerTrader>(this);
			if (compPowerTrader != null && compPowerTrader.PowerOn)
			{
				this.ticks++;
			}
			if (this.ticks >= this.ticksAirInterval)
			{
				if (this.ShouldAttackNow)
				{
					this.airThings = this.AirThings(this.AirCells);
					if (this.airThings.Count<Thing>() > 0)
					{
						Thing t = GenCollection.RandomElement<Thing>(this.airThings);
						this.turnAndAttack(t);
					}
				}
				this.ticks = 0;
			}
		}

		// Token: 0x0600001D RID: 29 RVA: 0x000030D0 File Offset: 0x000012D0
		private List<Thing> AirThings(IEnumerable<IntVec3> intVecs)
		{
			List<Thing> list = new List<Thing>();
			list.Clear();
			foreach (IntVec3 intVec in intVecs)
			{
				foreach (Thing thing in from x in base.Map.thingGrid.ThingsListAt(intVec)
				where x != null
				select x)
				{
					if (!(thing is Building) && thing.def.altitudeLayer != AltitudeLayer.BuildingOnTop && !(thing is Filth) && !(thing is Mote) && !(thing is Pawn) && !(thing is Plant) && this.IsAirTarget(thing))
					{
						list.Add(thing);
					}
				}
			}
			return list;
		}

		// Token: 0x0600001E RID: 30 RVA: 0x000031E0 File Offset: 0x000013E0
		public List<IntVec3> AirCellsAround(IntVec3 pos, Map map)
		{
			this.airCells.Clear();
			int num = GenRadial.NumCellsInRadius((float)this.range);
			for (int i = 0; i < num; i++)
			{
				this.airCells.Add(pos + GenRadial.RadialPattern[i]);
			}
			return this.airCells;
		}

		// Token: 0x0600001F RID: 31 RVA: 0x00003234 File Offset: 0x00001434
		private void turnAndAttack(Thing t)
		{
			if (this.IsAirTarget(t))
			{
				this.nowTarget = t;
				this.doTurretTick();
				SoundStarter.PlayOneShot(DefDatabase<SoundDef>.GetNamed(this.TopSizeComp.Props.soundShoot, true), new TargetInfo(base.Position, base.Map, true));
				FleckMaker.ThrowExplosionCell(base.Position, base.Map, FleckDefOf.ExplosionFlash, new Color(1f, 1f, 1f));
				MoteMaker.ThrowText(this.DrawPos, base.Map, Translator.Translate("AirDefenseHit"), new Color(0.66f, 0.66f, 0.12f), -1f);
				if (t is Projectile)
				{
					FleckMaker.ThrowSmoke(t.DrawPos, base.Map, 3f);
				}
				if (this.isPlayerInside(t) != null)
				{
					StringBuilder stringBuilder = new StringBuilder();
					string value = TranslatorFormattedStringExtensions.Translate("BeshotdownMsg", base.Faction.def.fixedName);
					stringBuilder.AppendLine(value);
					List<Pawn> list = this.isPlayerInside(t);
					if (list.Count > 0)
					{
						foreach (Pawn pawn in list)
						{
							StringBuilder stringBuilder2 = stringBuilder;
							string str = "    -";
							Name name = pawn.Name;
							stringBuilder2.AppendLine(str + ((name != null) ? name.ToString() : null));
						}
						Find.LetterStack.ReceiveLetter(Translator.Translate("Beshotdown"), stringBuilder.ToString(), LetterDefOf.Death, this, null, null, null, null);
					}
				}
				this.destoryAir(t);
				this.nowTarget = null;
			}
		}

		// Token: 0x06000020 RID: 32 RVA: 0x0000340C File Offset: 0x0000160C
		public void destoryAir(Thing t)
		{
			if (t is DropPodIncoming)
			{
				List<Thing> list = new List<Thing>();
				DropPodIncoming dropPodIncoming = t as DropPodIncoming;
				for (int i = dropPodIncoming.Contents.innerContainer.Count - 1; i >= 0; i--)
				{
					Thing thing = dropPodIncoming.Contents.innerContainer[i];
					if (thing is Pawn)
					{
						Pawn pawn = thing as Pawn;
						pawn.Kill(null, null);
						list.Add(pawn);
					}
					else
					{
						list.Add(thing);
					}
				}
				System.Random random = new System.Random();
				foreach (Thing thing2 in list)
				{
					if (thing2 is Pawn || random.Next(100) < Settings.droppodCargoDropPercentage)
					{
						GenPlace.TryPlaceThing(thing2, t.Position, base.Map, ThingPlaceMode.Near, null, null, default(Rot4));
						SoundStarter.PlayOneShot(SoundDefOf.DropPod_Open, new TargetInfo(thing2));
					}
				}
				for (int j = 0; j < 3; j++)
				{
					GenPlace.TryPlaceThing(ThingMaker.MakeThing(ThingDefOf.ChunkSlagSteel, null), t.Position, base.Map, ThingPlaceMode.Near, null, null, default(Rot4));
				}
			}
			t.Destroy(0);
		}

		// Token: 0x06000021 RID: 33 RVA: 0x00003580 File Offset: 0x00001780
		public override void ExposeData()
		{
			base.ExposeData();
			Scribe_Values.Look<int>(ref this.ticks, "ticks", 0, false);
		}

		// Token: 0x06000022 RID: 34 RVA: 0x0000359C File Offset: 0x0000179C
		private bool IsAirTarget(Thing t)
		{
			if (t is Projectile)
			{
				Projectile projectile = t as Projectile;
				if (!projectile.def.projectile.flyOverhead)
				{
					return false;
				}
				using (List<ProjectileEnd>.Enumerator enumerator = BulletStore.theBullet.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						ProjectileEnd projectileEnd = enumerator.Current;
						if (projectileEnd.shell == projectile && projectileEnd.launcher != null && (projectileEnd.launcher.Faction != base.Faction && FactionUtility.HostileTo(projectileEnd.launcher.Faction, base.Faction)))
						{
							return true;
						}
					}
					return false;
				}
			}
			if (t is DropPodIncoming)
			{
				DropPodIncoming dropPodIncoming = t as DropPodIncoming;
				for (int i = dropPodIncoming.Contents.innerContainer.Count - 1; i >= 0; i--)
				{
					Thing thing = dropPodIncoming.Contents.innerContainer[i];
					if (thing is Pawn)
					{
						Pawn pawn = thing as Pawn;
						if (pawn.Faction != base.Faction && FactionUtility.HostileTo(pawn.Faction, base.Faction))
						{
							return true;
						}
					}
				}
				return false;
			}
			return false;
		}

		// Token: 0x06000023 RID: 35 RVA: 0x000036EC File Offset: 0x000018EC
		public List<Pawn> isPlayerInside(Thing t)
		{
			List<Pawn> list = new List<Pawn>();
			if (t is DropPodIncoming)
			{
				DropPodIncoming dropPodIncoming = t as DropPodIncoming;
				for (int i = dropPodIncoming.Contents.innerContainer.Count - 1; i >= 0; i--)
				{
					Thing thing = dropPodIncoming.Contents.innerContainer[i];
					if (thing is Pawn)
					{
						Pawn pawn = thing as Pawn;
						if (pawn.Faction != base.Faction && FactionUtility.HostileTo(pawn.Faction, base.Faction) && pawn.Faction == Faction.OfPlayer)
						{
							list.Add(pawn);
						}
					}
				}
			}
			return list;
		}

		// Token: 0x06000024 RID: 36 RVA: 0x00003798 File Offset: 0x00001998
		private void doTurretTick()
		{
			CompPowerTrader compPowerTrader = ThingCompUtility.TryGetComp<CompPowerTrader>(this);
			if ((compPowerTrader == null || compPowerTrader.PowerOn) && base.Spawned)
			{
				this.top.TurretTopTick();
			}
		}

		// Token: 0x06000025 RID: 37 RVA: 0x000037CD File Offset: 0x000019CD
		public override void Draw()
		{
			if (this.def.IsBlueprint == false)
				this.top.DrawTurret();
			base.Comps_PostDraw();
		}
		// Token: 0x06000026 RID: 38 RVA: 0x000037E0 File Offset: 0x000019E0
		public override void SpawnSetup(Map map, bool respawningAfterLoad)
		{
			base.SpawnSetup(map, respawningAfterLoad);
			this.topSizeComp = base.GetComp<CompTurretTopSize>();
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000027 RID: 39 RVA: 0x000037F6 File Offset: 0x000019F6
		private int range
		{
			get
			{
				return 20;
			}
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x06000028 RID: 40 RVA: 0x00002ED6 File Offset: 0x000010D6
		private bool underRoof
		{
			get
			{
				return GridsUtility.Roofed(base.Position, base.Map);
			}
		}

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x06000029 RID: 41 RVA: 0x000037FA File Offset: 0x000019FA
		public CompTurretTopSize TopSizeComp
		{
			get
			{
				return this.topSizeComp;
			}
		}

		// Token: 0x0400000B RID: 11
		protected TurretTop_CustomSize top;

		// Token: 0x0400000C RID: 12
		protected CompTurretTopSize topSizeComp;

		// Token: 0x0400000D RID: 13
		protected StunHandler stunner;

		// Token: 0x0400000E RID: 14
		public LocalTargetInfo nowTarget;

		// Token: 0x0400000F RID: 15
		public List<IntVec3> airCells = new List<IntVec3>();

		// Token: 0x04000010 RID: 16
		private List<Thing> airThings = new List<Thing>();

		// Token: 0x04000011 RID: 17
		private int ticksAirInterval = 120;

		// Token: 0x04000012 RID: 18
		private int ticks;
	}
}
