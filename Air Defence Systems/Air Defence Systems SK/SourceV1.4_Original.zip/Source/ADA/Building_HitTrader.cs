﻿using Verse;

namespace ADA
{
	// Token: 0x02000004 RID: 4
	public class Building_HitTrader : Building
	{
	}
}
