﻿using System.Linq;
using HarmonyLib;
using RimWorld;
using Verse;

namespace ADA
{
	// Token: 0x0200000C RID: 12
	[HarmonyPatch(typeof(IncidentWorker_RaidEnemy), "ResolveRaidStrategy")]
	public static class Harmony_OpenADA
	{
		// Token: 0x06000049 RID: 73 RVA: 0x000046C4 File Offset: 0x000028C4
		public static void Postfix(IncidentWorker_RaidEnemy __instance, IncidentParms parms)
		{
			bool flag = parms.raidArrivalMode != PawnsArrivalModeDefOf.EdgeWalkIn;
			if (flag)
			{
				foreach (Map map in Find.Maps)
				{
					bool isPlayerHome = map.IsPlayerHome;
					if (isPlayerHome)
					{
						bool flag2 = map.listerBuildings.AllBuildingsColonistOfClass<Building_AirDefense>().ToList<Building_AirDefense>().Count > 0;
						if (flag2)
						{
							Messages.Message("ADA Open!", MessageTypeDefOf.PositiveEvent, false);
						}
						foreach (Building_AirDefense building_AirDefense in map.listerBuildings.AllBuildingsColonistOfClass<Building_AirDefense>())
						{
							building_AirDefense.OpenTick = 600;
						}
					}
				}
			}
		}
	}
}
