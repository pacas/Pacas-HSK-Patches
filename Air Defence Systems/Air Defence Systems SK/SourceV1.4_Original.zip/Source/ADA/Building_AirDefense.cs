﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace ADA
{
	// Token: 0x02000002 RID: 2
	public class Building_AirDefense : Building
	{
		// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
		public Building_AirDefense()
		{
			this.top = new TurretTop_CustomSize(this);
			this.stunner = new StunHandler(this);
			this.nowTarget = null;
			this.restoreBullet = 0;
			this.openTicks = 0;
		}

		// Token: 0x06000002 RID: 2 RVA: 0x000020AC File Offset: 0x000002AC
		public override string GetInspectString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append(base.GetInspectString());
			if (this.underRoof)
			{
				stringBuilder.Append("\n" + Translator.Translate("ADAUnderRoof") + "\n");
			}
			stringBuilder.Append(Translator.Translate("restoreBullet") + ":" + this.restoreBullet.ToString());
			if (this.restoreBullet < this.TopSizeComp.Props.maxStoreBullet)
			{
				stringBuilder.Append("\n");
				stringBuilder.Append(string.Concat(new object[]
				{
					Translator.Translate("restoreProgress"),
					":",
					(float)(this.ticks * 100 / this.ticksAirInterval),
					"%"
				}));
			}
			if (this.atkTicks > 0)
			{
				stringBuilder.Append(string.Concat(new string[]
				{
					"\n",
					Translator.Translate("atkTicks"),
					":",
					((float)((double)((float)this.atkTicks * 1f) / 60.0)).ToString("#0.0"),
					Translator.Translate("ra2Sec")
				}));
			}
			return stringBuilder.ToString();
		}

		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000003 RID: 3 RVA: 0x00002221 File Offset: 0x00000421
		private IEnumerable<IntVec3> AirCells
		{
			get
			{
				return this.AirCellsAround(base.Position, base.Map);
			}
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000004 RID: 4 RVA: 0x00002238 File Offset: 0x00000438
		private bool ShouldAttackNow
		{
			get
			{
				bool result;
				if (!base.Spawned)
				{
					result = false;
				}
				else if (!FlickUtility.WantsToBeOn(this))
				{
					result = false;
				}
				else if (this.underRoof)
				{
					result = false;
				}
				else if (this.atkTicks > 0)
				{
					result = false;
				}
				else if (this.openTicks < 1)
				{
					result = false;
				}
				else
				{
					CompPowerTrader compPowerTrader = ThingCompUtility.TryGetComp<CompPowerTrader>(this);
					if (compPowerTrader != null && !compPowerTrader.PowerOn)
					{
						result = false;
					}
					else if (this.stunner.Stunned)
					{
						result = false;
					}
					else
					{
						CompRefuelable compRefuelable = ThingCompUtility.TryGetComp<CompRefuelable>(this);
						result = (compRefuelable == null || compRefuelable.HasFuel);
					}
				}
				return result;
			}
		}

		// Token: 0x06000005 RID: 5 RVA: 0x000022D0 File Offset: 0x000004D0
		public override void Tick()
		{
			base.Tick();
			this.doTurretTick();
			if (this.restoreBullet < this.TopSizeComp.Props.maxStoreBullet)
			{
				CompPowerTrader compPowerTrader = ThingCompUtility.TryGetComp<CompPowerTrader>(this);
				if (compPowerTrader != null && compPowerTrader.PowerOn)
				{
					this.ticks++;
				}
			}
			if (this.atkTicks > 0)
			{
				this.atkTicks--;
			}
			if (this.openTicks > 0)
			{
				this.openTicks--;
			}
			if (this.ticks >= this.ticksAirInterval)
			{
				this.restoreBullet++;
				this.ticks = 0;
			}
			if (this.restoreBullet > 0 && this.ShouldAttackNow)
			{
				this.airThings = this.AirThings(this.AirCells);
				if (this.airThings.Count<Thing>() > 0)
				{
					Thing t = GenCollection.RandomElement<Thing>(this.airThings);
					this.turnAndAttack(t);
					return;
				}
				this.nowTarget = null;
			}
		}

		// Token: 0x06000006 RID: 6 RVA: 0x000023D8 File Offset: 0x000005D8
		private List<Thing> AirThings(IEnumerable<IntVec3> intVecs)
		{
			List<Thing> list = new List<Thing>();
			list.Clear();
			foreach (IntVec3 intVec in intVecs)
			{
				foreach (Thing thing in from x in base.Map.thingGrid.ThingsListAt(intVec)
				where x != null
				select x)
				{
					if (!(thing is Building) && thing.def.altitudeLayer != AltitudeLayer.BuildingOnTop && !(thing is Filth) && !(thing is Mote) && !(thing is Pawn) && !(thing is Plant) && this.IsAirTarget(thing))
					{
						list.Add(thing);
						return list;
					}
				}
			}
			return list;
		}

		// Token: 0x06000007 RID: 7 RVA: 0x000024F0 File Offset: 0x000006F0
		public List<IntVec3> AirCellsAround(IntVec3 pos, Map map)
		{
			List<IntVec3> result;
			if (this.airCells.Count > 0)
			{
				result = this.airCells;
			}
			else
			{
				int num = GenRadial.NumCellsInRadius((float)this.range);
				for (int i = 0; i < num; i++)
				{
					this.airCells.Add(pos + GenRadial.RadialPattern[i]);
				}
				result = this.airCells;
			}
			return result;
		}

		// Token: 0x06000008 RID: 8 RVA: 0x00002554 File Offset: 0x00000754
		public List<IntVec3> HugeGetCells(IntVec3 pos, Map map)
		{
			List<IntVec3> list = new List<IntVec3>();
			int num = GenRadial.NumCellsInRadius(10f);
			for (int i = 0; i < num; i++)
			{
				list.Add(pos + GenRadial.RadialPattern[i]);
			}
			return list;
		}

		// Token: 0x06000009 RID: 9 RVA: 0x00002598 File Offset: 0x00000798
		private List<Thing> HugeAirThings(IEnumerable<IntVec3> intVecs)
		{
			List<Thing> list = new List<Thing>();
			list.Clear();
			foreach (IntVec3 intVec in intVecs)
			{
				foreach (Thing thing in from x in base.Map.thingGrid.ThingsListAt(intVec)
				where x != null
				select x)
				{
					if (!(thing is Building) && thing.def.altitudeLayer != AltitudeLayer.BuildingOnTop && !(thing is Filth) && !(thing is Mote) && !(thing is Pawn) && !(thing is Plant) && this.IsAirTarget(thing))
					{
						list.Add(thing);
					}
				}
			}
			return list;
		}

		// Token: 0x0600000A RID: 10 RVA: 0x000026A8 File Offset: 0x000008A8
		private void turnAndAttack(Thing t)
		{
			if (this.IsAirTarget(t))
			{
				this.nowTarget = t;
				this.doTurretTick();
				if (!this.TopSizeComp.Props.canShotShip || this.top.aimCanATK)
				{
					SoundStarter.PlayOneShot(DefDatabase<SoundDef>.GetNamed(this.TopSizeComp.Props.soundShoot, true), new TargetInfo(base.Position, base.Map, true));
					FleckMaker.ThrowExplosionCell(base.Position, base.Map, FleckDefOf.ExplosionFlash, new Color(1f, 1f, 1f));
					MoteMaker.ThrowText(this.DrawPos, base.Map, Translator.Translate("AirDefenseHit"), new Color(0.66f, 0.66f, 0.12f), -1f);
					if (t is Projectile)
					{
						FleckMaker.ThrowSmoke(t.DrawPos, base.Map, 3f);
					}
					else if (this.TopSizeComp.Props.canShotShip)
					{
						int num = (int)(Math.Sin((double)this.top.CurRotation * 3.141592653589793 / 180.0) * 10.0);
						int num2 = (int)(Math.Cos((double)this.top.CurRotation * 3.141592653589793 / 180.0) * 10.0);
						MoteMaker.MakeBombardmentMote(base.Position + new IntVec3(num, 0, num2), base.Map, 1);
						SoundStarter.PlayOneShot(SoundDefOf.Thunder_OnMap, new TargetInfo(base.Position, base.Map, true));
						float magnitude = (base.Position.ToVector3Shifted() - Find.Camera.transform.position).magnitude;
						Find.CameraDriver.shaker.DoShake(60f / magnitude);
					}
					if (t is DropPodIncoming && this.TopSizeComp.Props.canShotShip)
					{
						foreach (Thing thing in this.HugeAirThings(this.HugeGetCells(t.Position, base.Map)))
						{
							if ((thing == null || thing != t) && (thing != null && !thing.Destroyed))
							{
								this.destoryAir(thing);
							}
						}
					}
					this.destoryAir(t);
					this.nowTarget = null;
					this.restoreBullet--;
					this.top.aimCanATK = false;
					this.atkTicks = this.TopSizeComp.Props.atkTicks;
				}
			}
		}

		// Token: 0x0600000B RID: 11 RVA: 0x0000298C File Offset: 0x00000B8C
		public void destoryAir(Thing t)
		{
			List<Thing> list = new List<Thing>();
			if (t is DropPodIncoming)
			{
				DropPodIncoming dropPodIncoming = t as DropPodIncoming;
				for (int i = dropPodIncoming.Contents.innerContainer.Count - 1; i >= 0; i--)
				{
					Thing thing = dropPodIncoming.Contents.innerContainer[i];
					if (thing != null)
					{
						if (thing is Pawn)
						{
							Pawn pawn = thing as Pawn;
							//HealthUtility.DamageUntilDowned(pawn, true);
							//pawn.TakeDamage(new DamageInfo(DamageDefOf.Stun, 1200,1200));
							//pawn.stances.stunner.StunFor(1200, null, false);
							list.Add(pawn);
						}
						else
						{
							list.Add(thing);
						}
					}
				}
				System.Random random = new System.Random();
				foreach (Thing thing2 in list)
				{
					if (thing2 is Pawn || random.Next(100) < Settings.droppodCargoDropPercentage)
					{
						GenPlace.TryPlaceThing(thing2, t.Position, base.Map, ThingPlaceMode.Near, null, null, default(Rot4));
						SoundStarter.PlayOneShot(SoundDefOf.DropPod_Open, new TargetInfo(thing2));
					}
				}
				for (int j = 0; j < 3; j++)
				{
					GenPlace.TryPlaceThing(ThingMaker.MakeThing(ThingDefOf.ChunkSlagSteel, null), t.Position, base.Map, ThingPlaceMode.Near, null, null, default(Rot4));
				}
			}
			else if (t is Skyfaller && ((t as Skyfaller).def.defName == "CrashedShipPartIncoming" || (t as Skyfaller).def.defName == "VFEI_InsectMeteoriteIncoming"))
			{
				GenExplosion.DoExplosion(t.Position, t.Map, 2f, DamageDefOf.Bomb, this, 3, -1f, DefDatabase<SoundDef>.GetNamed("Explosion_Bomb", true), null, null, t, null, 0f, 1, null, false, null, 0f, 1, 0f, false, null, null);
				for (int k = 0; k < 15; k++)
				{
					ThingMaker.MakeThing(ThingDefOf.ChunkSlagSteel, null);
				}
			}
			if (t != null)
			{
				t.Destroy(0);
				foreach (Pawn pawnstuff in list)
				{
					HealthUtility.DamageUntilDowned(pawnstuff, true);
					pawnstuff.stances.stunner.StunFor(1200, null, false);
				}
			}
		}

		// Token: 0x0600000C RID: 12 RVA: 0x00002B98 File Offset: 0x00000D98
		public override void ExposeData()
		{
			base.ExposeData();
			Scribe_Values.Look<int>(ref this.ticks, "ticks", 0, false);
			Scribe_Values.Look<int>(ref this.restoreBullet, "restoreBullet", 0, false);
			Scribe_Values.Look<int>(ref this.atkTicks, "atkTicks", 0, false);
			Scribe_Values.Look<int>(ref this.openTicks, "openTicks", 0, false);
		}

		// Token: 0x0600000D RID: 13 RVA: 0x00002BF4 File Offset: 0x00000DF4
		private bool IsAirTarget(Thing t)
		{
			if (t is Projectile && !this.TopSizeComp.Props.canShotShip)
			{
				Projectile projectile = t as Projectile;
				if (!projectile.def.projectile.flyOverhead)
				{
					return false;
				}
				using (List<ProjectileEnd>.Enumerator enumerator = BulletStore.theBullet.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						ProjectileEnd projectileEnd = enumerator.Current;
						if (projectileEnd.shell == projectile && projectileEnd.launcher != null && (projectileEnd.launcher.Faction != base.Faction && FactionUtility.HostileTo(projectileEnd.launcher.Faction, base.Faction)))
						{
							return true;
						}
					}
					return false;
				}
			}
			if (t is DropPodIncoming && this.TopSizeComp.Props.canShotPod)
			{
				DropPodIncoming dropPodIncoming = t as DropPodIncoming;
				for (int i = dropPodIncoming.Contents.innerContainer.Count - 1; i >= 0; i--)
				{
					Thing thing = dropPodIncoming.Contents.innerContainer[i];
					if (thing is Pawn)
					{
						Pawn pawn = thing as Pawn;
						if (pawn.Faction != base.Faction && FactionUtility.HostileTo(pawn.Faction, base.Faction))
						{
							return true;
						}
					}
				}
				return false;
			}
			if (t is Skyfaller && ((t as Skyfaller).def.defName == "CrashedShipPartIncoming" || (t as Skyfaller).def.defName =="VFEI_InsectMeteoriteIncoming") && this.TopSizeComp.Props.canShotShip)
			{
				return true;
			}
			return false;
		}

		// Token: 0x0600000E RID: 14 RVA: 0x00002DA8 File Offset: 0x00000FA8
		public List<Pawn> isPlayerInside(Thing t)
		{
			List<Pawn> list = new List<Pawn>();
			if (t is DropPodIncoming)
			{
				DropPodIncoming dropPodIncoming = t as DropPodIncoming;
				for (int i = dropPodIncoming.Contents.innerContainer.Count - 1; i >= 0; i--)
				{
					Thing thing = dropPodIncoming.Contents.innerContainer[i];
					if (thing is Pawn)
					{
						Pawn pawn = thing as Pawn;
						if (pawn.Faction != base.Faction && FactionUtility.HostileTo(pawn.Faction, base.Faction) && pawn.Faction == Faction.OfPlayer)
						{
							list.Add(pawn);
						}
					}
				}
			}
			return list;
		}

		// Token: 0x0600000F RID: 15 RVA: 0x00002E54 File Offset: 0x00001054
		private void doTurretTick()
		{
			CompPowerTrader compPowerTrader = ThingCompUtility.TryGetComp<CompPowerTrader>(this);
			if ((compPowerTrader == null || compPowerTrader.PowerOn) && base.Spawned)
			{
				this.top.TurretTopTick();
			}
		}

		// Token: 0x06000010 RID: 16 RVA: 0x00002E89 File Offset: 0x00001089
		public override void Draw()
		{
			if(this.def.IsBlueprint == false)
				this.top.DrawTurret();
			base.Comps_PostDraw();
		}
		// Token: 0x06000011 RID: 17 RVA: 0x00002E9C File Offset: 0x0000109C
		public override void SpawnSetup(Map map, bool respawningAfterLoad)
		{
			base.SpawnSetup(map, respawningAfterLoad);
			this.topSizeComp = base.GetComp<CompTurretTopSize>();
		}

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x06000012 RID: 18 RVA: 0x00002EB2 File Offset: 0x000010B2
		private int range
		{
			get
			{
				return this.TopSizeComp.Props.atkRange;
			}
		}

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x06000013 RID: 19 RVA: 0x00002EC4 File Offset: 0x000010C4
		private int ticksAirInterval
		{
			get
			{
				return this.TopSizeComp.Props.storeTick;
			}
		}

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x06000014 RID: 20 RVA: 0x00002ED6 File Offset: 0x000010D6
		private bool underRoof
		{
			get
			{
				return GridsUtility.Roofed(base.Position, base.Map);
			}
		}

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000015 RID: 21 RVA: 0x00002EE9 File Offset: 0x000010E9
		// (set) Token: 0x06000016 RID: 22 RVA: 0x00002EF1 File Offset: 0x000010F1
		public int OpenTick
		{
			get
			{
				return this.openTicks;
			}
			set
			{
				this.openTicks = value;
			}
		}

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000017 RID: 23 RVA: 0x00002EFA File Offset: 0x000010FA
		public CompTurretTopSize TopSizeComp
		{
			get
			{
				return this.topSizeComp;
			}
		}

		// Token: 0x04000001 RID: 1
		protected TurretTop_CustomSize top;

		// Token: 0x04000002 RID: 2
		protected CompTurretTopSize topSizeComp;

		// Token: 0x04000003 RID: 3
		protected StunHandler stunner;

		// Token: 0x04000004 RID: 4
		public LocalTargetInfo nowTarget;

		// Token: 0x04000005 RID: 5
		public List<IntVec3> airCells = new List<IntVec3>();

		// Token: 0x04000006 RID: 6
		private List<Thing> airThings = new List<Thing>();

		// Token: 0x04000007 RID: 7
		private int ticks;

		// Token: 0x04000008 RID: 8
		private int atkTicks;

		// Token: 0x04000009 RID: 9
		private int openTicks;

		// Token: 0x0400000A RID: 10
		private int restoreBullet;
	}
}
