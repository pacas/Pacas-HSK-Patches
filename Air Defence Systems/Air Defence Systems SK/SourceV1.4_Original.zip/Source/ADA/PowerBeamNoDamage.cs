﻿using RimWorld;
using Verse;

namespace ADA
{
	// Token: 0x02000011 RID: 17
	public class PowerBeamNoDamage : OrbitalStrike
	{
		// Token: 0x06000053 RID: 83 RVA: 0x00004A94 File Offset: 0x00002C94
		public override void StartStrike()
		{
			base.StartStrike();
			MoteMaker.MakePowerBeamMote(this.pos, this.map);
			float magnitude = (this.pos.ToVector3Shifted() - Find.Camera.transform.position).magnitude;
			Find.CameraDriver.shaker.DoShake(150000f / magnitude);
		}

		// Token: 0x04000025 RID: 37
		public IntVec3 pos;

		// Token: 0x04000026 RID: 38
		public Map map;
	}
}
