﻿using Verse;

namespace ADA
{
	// Token: 0x02000008 RID: 8
	public class CompProperties_HitPassingShip : CompProperties
	{
		// Token: 0x06000044 RID: 68 RVA: 0x0000460C File Offset: 0x0000280C
		public CompProperties_HitPassingShip()
		{
			this.compClass = typeof(CompHitPassingShip);
		}
	}
}
