﻿using System;
using Verse;

namespace ADA
{
	// Token: 0x02000012 RID: 18
	public class ProjectileEnd
	{
		// Token: 0x06000055 RID: 85 RVA: 0x00004B03 File Offset: 0x00002D03
		public ProjectileEnd(Projectile s, Thing l)
		{
			this.shell = s;
			this.launcher = l;
		}

		// Token: 0x04000027 RID: 39
		public Thing launcher;

		// Token: 0x04000028 RID: 40
		public Projectile shell;
	}
}
