﻿using System.Collections.Generic;
using System.Text;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Noise;
using Verse.Sound;

namespace ADA
{
	// Token: 0x02000006 RID: 6
	public class CompHitPassingShip : ThingComp
	{
		// Token: 0x1700000D RID: 13
		// (get) Token: 0x0600002D RID: 45 RVA: 0x00003BBC File Offset: 0x00001DBC
		public CompProperties_HitPassingShip Props
		{
			get
			{
				return (CompProperties_HitPassingShip)this.props;
			}
		}

		// Token: 0x0600002E RID: 46 RVA: 0x00003BDC File Offset: 0x00001DDC
		public override string CompInspectStringExtra()
		{
			StringBuilder stringBuilder = new StringBuilder();
			bool flag = this.target == null;
			if (flag)
			{
				stringBuilder.Append(Translator.Translate("ADA_Hit_NoTarget"));
			}
			else
			{
				stringBuilder.Append(Translator.Translate("ADA_Hit_Target") + ":" + this.target.name);
				bool fiya = this.Fiya;
				if (fiya)
				{
					stringBuilder.Append("\n" + Translator.Translate("FireProgress") + ":");
					bool flag2 = this.getPercent() > 1f;
					if (flag2)
					{
						stringBuilder.Append("100.0%");
					}
					else
					{
						stringBuilder.Append((this.getPercent() * 100f).ToString("f1") + "%");
					}
				}
			}
			return stringBuilder.ToString();
		}

		// Token: 0x0600002F RID: 47 RVA: 0x00003CC4 File Offset: 0x00001EC4
		public float getPercent()
		{
			return (float)this.ticks * 1f / 600f;
		}

		// Token: 0x06000030 RID: 48 RVA: 0x00003CE9 File Offset: 0x00001EE9
		public override void PostSpawnSetup(bool respawningAfterLoad)
		{
			base.PostSpawnSetup(respawningAfterLoad);
		}

		// Token: 0x06000031 RID: 49 RVA: 0x00003CF4 File Offset: 0x00001EF4
		public override void Initialize(CompProperties props)
		{
			base.Initialize(props);
			this.ticks = 0;
			this.target = null;
		}

		// Token: 0x06000032 RID: 50 RVA: 0x00003D0D File Offset: 0x00001F0D
		public override void PostExposeData()
		{
			Scribe_Values.Look<int>(ref this.ticks, "ticks", 0, false);
			Scribe_References.Look<PassingShip>(ref this.target, "target", false);
			Scribe_Values.Look<bool>(ref this.Fiya, "Fiya", false, false);
		}

		// Token: 0x06000033 RID: 51 RVA: 0x00003D48 File Offset: 0x00001F48
		public override void CompTick()
		{
			base.CompTick();
			CompPowerTrader compPowerTrader = ThingCompUtility.TryGetComp<CompPowerTrader>(this.parent);
			bool flag = this.target != null && !this.parent.Map.passingShipManager.passingShips.Contains(this.target);
			if (flag)
			{
				this.target = null;
				this.Fiya = false;
			}
			bool flag2 = compPowerTrader != null && compPowerTrader.PowerOn;
			if (flag2)
			{
				bool flag3 = this.target != null;
				if (flag3)
				{
					bool flag4 = this.Fiya && this.ticks <= 1300;
					if (flag4)
					{
						this.ticks++;
					}
				}
			}
			else
			{
				this.ticks = 0;
				this.Fiya = false;
			}
			bool flag5 = this.ticks == 700;
			if (flag5)
			{
				this.drawBeam();
			}
			bool flag6 = this.ticks > 1240 && this.ticks % 3 == 0;
			if (flag6)
			{
				SoundStarter.PlayOneShot(DefDatabase<SoundDef>.GetNamed("Explosion_Bomb", true), this.parent);
			}
			bool flag7 = this.ticks == 1300;
			if (flag7)
			{
				this.shotDownTraderShip();
			}
		}

		// Token: 0x06000034 RID: 52 RVA: 0x00003E84 File Offset: 0x00002084
		private void drawBeam()
		{
			float magnitude = (this.parent.Position.ToVector3Shifted() - Find.Camera.transform.position).magnitude;
			Find.CameraDriver.shaker.DoShake(300000f / magnitude);
			PowerBeamNoDamage powerBeamNoDamage = (PowerBeamNoDamage)GenSpawn.Spawn(DefDatabase<ThingDef>.GetNamed("PowerBeamNoDamage", true), this.parent.Position, this.parent.Map, 0);
			powerBeamNoDamage.duration = 600;
			powerBeamNoDamage.instigator = this.parent;
			powerBeamNoDamage.weaponDef = null;
			powerBeamNoDamage.pos = this.parent.Position;
			powerBeamNoDamage.map = this.parent.Map;
			powerBeamNoDamage.StartStrike();
		}

		// Token: 0x06000035 RID: 53 RVA: 0x00003F50 File Offset: 0x00002150
		private void shotDownTraderShip()
		{
			bool flag = this.target is TradeShip;
			if (flag)
			{
				TradeShip tradeShip = this.target as TradeShip;
				List<Thing> list = new List<Thing>();
				System.Random random = new System.Random(114514);
				list.Add(ThingMaker.MakeThing(ThingDefOf.ChunkSlagSteel, null));
				foreach (Thing item in tradeShip.Goods)
				{
					int num = random.Next(100);
					bool flag2 = num >= Settings.droppodCargoDropPercentage;
					if (!flag2)
					{
						list.Add(item);
					}
				}
				this.parent.Map.passingShipManager.RemoveShip(this.target);
				int count = this.parent.Map.passingShipManager.passingShips.Count;
				bool flag3 = count > 0;
				if (flag3)
				{
					for (int i = 0; i < count; i++)
					{
						this.parent.Map.passingShipManager.passingShips[0].Depart();
					}
				}
				foreach (Thing thing in list)
				{
					thing.holdingOwner = null;
				}
				IntVec3 intVec = DropCellFinder.RandomDropSpot(this.parent.Map);
				Thing thing2 = list[0];
				DropPodUtility.DropThingsNear(intVec, this.parent.Map, list, 30, false, true, true);


				Find.LetterStack.ReceiveLetter(TranslatorFormattedStringExtensions.Translate("PassingShipShotDown"),
					TranslatorFormattedStringExtensions.Translate("PassingShipShotDownMsg"), LetterDefOf.PositiveEvent, thing2, null, null);
				this.ticks = 0;
				this.Fiya = false;
				this.target = null;
				ThingCompUtility.TryGetComp<CompHitTop>(this.parent).cooldownticks = 700;
				foreach (Faction faction in Find.FactionManager.AllFactionsVisible)
				{
					bool flag4 = faction != Faction.OfPlayer;
					if (flag4)
					{
						//faction.TryAffectGoodwillWith(Faction.OfPlayer, -30, true, true, Translator.Translate("ReasonHitTradeShip"), null);
						faction.TryAffectGoodwillWith(Faction.OfPlayer, -30, true, true, null, null);
					}
				}
				ThingCompUtility.TryGetComp<CompRefuelable>(this.parent).ConsumeFuel(1f);
			}
		}

		// Token: 0x06000036 RID: 54 RVA: 0x00004208 File Offset: 0x00002408
		public override IEnumerable<Gizmo> CompGetGizmosExtra()
		{
			bool flag = this.parent.Map.passingShipManager.passingShips.Count < 1;
			if (flag)
			{
				Command_Action command_Action = new Command_Action();
				command_Action.defaultLabel = Translator.Translate("ADA_NoShip");
				command_Action.action = delegate()
				{
				};
				yield return command_Action;
			}
			else
			{
				bool flag2 = this.parent.Map.passingShipManager.passingShips.Count > 0;
				if (flag2)
				{
					foreach (PassingShip ps in this.parent.Map.passingShipManager.passingShips)
					{
						yield return this.CAction(ps);
						//ps = null;
					}
					List<PassingShip>.Enumerator enumerator = default(List<PassingShip>.Enumerator);
				}
			}
			bool flag3 = this.target != null;
			if (flag3)
			{
				yield return new Command_Action
				{
					icon = ContentFinder<Texture2D>.Get(this.Fiya ? "UI/Commands/HoldFire" : "Things/Mote/BattleSymbols/SkullTarget", true),
					defaultLabel = (this.Fiya ? Translator.Translate("CommandHoldFire") : Translator.Translate("ADA_Fiya")),
					disabled = !this.canFiyaToggle(),
					action = delegate()
					{
						this.Fiya = !this.Fiya;
						bool flag4 = !this.Fiya;
						if (flag4)
						{
							ThingCompUtility.TryGetComp<CompHitTop>(this.parent).cooldownticks = this.ticks;
							this.ticks = 0;
						}
					}
				};
			}
			yield break;
		}

		// Token: 0x06000037 RID: 55 RVA: 0x00004218 File Offset: 0x00002418
		private bool canFiyaToggle()
		{
			bool flag = ThingCompUtility.TryGetComp<CompHitTop>(this.parent).cooldownticks > 0;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool flag2 = ThingCompUtility.TryGetComp<CompRefuelable>(this.parent).Fuel < 1f;
				if (flag2)
				{
					result = false;
				}
				else
				{
					bool flag3 = this.ticks > 699;
					result = !flag3;
				}
			}
			return result;
		}

		// Token: 0x06000038 RID: 56 RVA: 0x00004280 File Offset: 0x00002480
		private Command_Action CAction(PassingShip ps)
		{
			return new Command_Action
			{
				icon = ContentFinder<Texture2D>.Get("Things/Special/DropPod", true),
				defaultLabel = Translator.Translate("ADA_Hit") + ps.name,
				action = delegate()
				{
					bool flag = this.target != ps && !this.Fiya;
					if (flag)
					{
						this.target = ps;
					}
					else
					{
						bool flag2 = this.target == ps;
						if (flag2)
						{
							this.target = null;
						}
					}
				}
			};
		}

		// Token: 0x04000014 RID: 20
		private int ticks = 0;

		// Token: 0x04000015 RID: 21
		private PassingShip target = null;

		// Token: 0x04000016 RID: 22
		public bool Fiya = false;
	}
}
