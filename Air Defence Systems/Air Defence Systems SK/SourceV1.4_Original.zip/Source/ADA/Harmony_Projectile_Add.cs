﻿using System;
using HarmonyLib;
using UnityEngine;
using Verse;

namespace ADA
{
	// Token: 0x0200000E RID: 14
	[HarmonyPatch(typeof(Projectile), "Launch", new Type[]
	{
		typeof(Thing),
		typeof(Vector3),
		typeof(LocalTargetInfo),
		typeof(LocalTargetInfo),
		typeof(ProjectileHitFlags),
		typeof(Thing),
		typeof(ThingDef)
	})]
	public static class Harmony_Projectile_Add
	{
		// Token: 0x0600004B RID: 75 RVA: 0x000048E8 File Offset: 0x00002AE8
		public static void Postfix(Projectile __instance)
		{
			bool flag = __instance.def.projectile != null && __instance.def.projectile.flyOverhead;
			if (flag)
			{
				Traverse traverse = Traverse.Create(__instance);
				Thing value = traverse.Field("launcher").GetValue<Thing>();
				ProjectileEnd item = new ProjectileEnd(__instance, value);
				bool flag2 = !BulletStore.theBullet.Contains(item);
				if (flag2)
				{
					BulletStore.theBullet.Add(item);
				}
			}
		}
	}
}
